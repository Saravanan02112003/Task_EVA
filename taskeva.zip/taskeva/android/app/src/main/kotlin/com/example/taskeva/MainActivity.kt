package com.example.taskeva

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
